import React from "react";
// import { Dimensions, Stylesheet, ScrollView, ImageBackground, View} from "react-native";
import Weather from "./components/weather";
import { BrowserRouter as Router,Routes, Route, Link } from "react-router-dom";

class App extends React.Component {
  render() {
    
    return (
      <div   style={{
        backgroundImage: `url("bg.jpg")`, 
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        width:"100vm",
        height:"100vh",
        // backgroundAttachment: "fixed",
        margin: 0,
        padding: 0,
        overflow: "auto",
      }} className="AppBody">
        <h1 style={{fontSize: '40px',
    color: 'black', textAlign:'center'}} className="WeatherForecastMainHeading">WEATHER APP</h1>
      <Router>
        <div className="wrapper">
          <Link to='/weekly'><button style={{marginTop: '50px', marginBottom: '50px',}}>Search By Location</button></Link>
              </div>
              <div className="row">
                <Routes>
                {/* <Route path="/weekly" element={Weather} /> */}
                <Route path="/weekly" element={<Weather/>} />
                </Routes>
        </div>
      </Router>
      </div>
    );
  }
}

export default App;
